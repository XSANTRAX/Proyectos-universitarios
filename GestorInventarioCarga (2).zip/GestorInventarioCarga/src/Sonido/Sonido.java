/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sonido;
import javax.sound.sampled.*;
import java.io.File;
/**
 *
 * @author Usuario
 */
public class Sonido {
   private static Sonido instancia;
    private Clip clip;

    public Sonido() {}

    public static Sonido getInstancia() {
        if (instancia == null) {
            instancia = new Sonido();
        }
        return instancia;
    }
    public void reproducir(String ruta) {
        try {
        AudioInputStream audio = AudioSystem.getAudioInputStream(getClass().getResource("trance-009-sound-system-dreamscape-made-with-Voicemod.wav"));
        clip = AudioSystem.getClip();
        clip.open(audio);
        clip.start();
        clip.loop(Clip.LOOP_CONTINUOUSLY); // Reproduce en bucle
    } catch (Exception e) {
        System.out.println("No se pudo reproducir el audio.");
        e.printStackTrace();
    }
    }

}

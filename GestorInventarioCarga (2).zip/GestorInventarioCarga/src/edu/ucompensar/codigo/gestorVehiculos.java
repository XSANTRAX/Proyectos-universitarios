package edu.ucompensar.codigo;

import java.util.LinkedList;
import javax.swing.JOptionPane;

//La clase gestorVehiculos implementa la interfaz llamada calcularTarifa pa usar su metodo y constantes.
public class gestorVehiculos implements calcularTarifa {

    // Se crean las diferentes listas (LinkedList) para almacenar toda la información, incluyendo los conductores, vehículos, productos y asignaciones que se realizarán.
    public static LinkedList<Vehiculo> veh = new LinkedList<>();
    public static LinkedList<Conductores> cond = new LinkedList<>();
    public static LinkedList<Productos> prod = new LinkedList<>();
    public static LinkedList<Asignación> asigna = new LinkedList<>();

    //Metodo que buscara especificamente el vehiculo determinado por la placa para asignarle su conductor y prodcto a llevar a su destino.
    public Vehiculo buscarVehiculo(String placa) {
        for (Vehiculo vehiculo : veh) {
            if (vehiculo.getPlaca().equalsIgnoreCase(placa)) {
                return vehiculo;
            }
        }
        return null;
    }

    //Metodo que buscara especificamente el conductor determinado por su identificación para asignarle su vehiculo  y prodcto a llevar.
    public Conductores buscarConductor(String identificacion) {
        for (Conductores conductor : cond) {
            if (conductor.getIdentificacion().equals(identificacion)) {
                return conductor;
            }
        }
        return null;
    }

    //Metodo que buscara especificamente el producto determinado por la marca para asignarle su conductor y vehiculo el cual lo llevata a su destino.
    public Productos buscarProducto(String marca) {
        for (Productos producto : prod) {
            if (producto.getMarca().equals(marca)) {
                return producto;
            }
        }
        return null;
    }

    //Metodo destinado a calcular la tarifa por tonelada de cada vehiculo dependiento de su numero de ejes.
    @Override
    public int calculaCargaTarifa(String placa, int toneladas) {
        Vehiculo vehiculo = buscarVehiculo(placa);

        if (vehiculo == null) {
            JOptionPane.showMessageDialog(null,"Error: Vehículo no encontrado.");
            return 0;
           
        }

        if (toneladas > vehiculo.getCapacidad()) {
            JOptionPane.showMessageDialog(null,"Error: La carga excede la capacidad del vehículo.");
            return 0;
        }

        switch (vehiculo.getEjes()) {
            case 2:
                return ejes2 * toneladas;
            case 3:
                return ejes3 * toneladas;
            case 4:
                return ejes4 * toneladas;
            case 5:
                return ejes5 * toneladas;
            case 6:
                return ejes6 * toneladas;
            default:
                JOptionPane.showMessageDialog(null,"Error: Número de ejes no válido.");
                return 0;
        }
    }

    //Metodo que se dedica a realizar la debida asignación de condutor, vehiculo y producto ademas de las toneladas del producto que lleva y su tarifa.
    public boolean realizarAsignacion(String identificacion, String placa, String marca, int toneladas) {
        Conductores conductor = buscarConductor(identificacion);
        Vehiculo vehiculo = buscarVehiculo(placa);
        Productos producto = buscarProducto(marca);

        if (conductor == null) {
            JOptionPane.showMessageDialog(null,"Asignación fallida: Conductor con identificación " + identificacion + " no encontrado.");
            return false;
        }

        if (!conductor.getDisponibilidad()) {
            JOptionPane.showMessageDialog(null,"Asignación fallida: Conductor con identificacion " + identificacion + " no está disponible.");
            return false;
        }

        if (vehiculo == null) {
            JOptionPane.showMessageDialog(null,"Asignación fallida: Vehículo con placa " + placa + " no encontrado.");
            return false;
        }

        if (!vehiculo.getDisponibilidad()) {
            JOptionPane.showMessageDialog(null,"Asignación fallida: Vehículo con placa " + placa + " no está disponible.");
            return false;
        }

        if (producto == null) {
            JOptionPane.showMessageDialog(null,"Asignación fallida: Producto con marca " + marca + " no encontrado.");
            return false;
        }

        int tarifa = calculaCargaTarifa(placa, toneladas);

        if (tarifa == 0) {
            JOptionPane.showMessageDialog(null,"Asignación fallida: No se pudo calcular la tarifa.");
            return false;
        }

        Asignación asig = new Asignación(vehiculo, conductor, producto, toneladas, tarifa);
        asigna.add(asig);
        vehiculo.setDisponibilidad(false);
        conductor.setDisponibilidad(false);

        JOptionPane.showMessageDialog(null,"Asignación realizada con éxito: " + conductor.getNombre() + " conducirá " + vehiculo.getPlaca());
        return true;
    }

    //Metodo que muestra todas las asignaciones realizadas que estan almacenadas en la lista asigna.
    public void mostrarAsignaciones() {
        for (Asignación asignacion : asigna) {
            System.out.println(asignacion.info());
            System.out.println("--------------------------------------------------------------");
        }
    }

    //Metodo que ordena la lista de asignaciones a traves de la placa del vehiculo de forma alfabetica
    public void ordenarAsignacionesSeleccion() {
        if (asigna == null || asigna.isEmpty()) {
            JOptionPane.showMessageDialog(null,"La lista está vacía...");
            return;
        }

        int n = asigna.size();

        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;

            for (int j = i + 1; j < n; j++) {
                if (asigna.get(j).getVehiculo().getPlaca().compareToIgnoreCase(asigna.get(minIndex).getVehiculo().getPlaca()) < 0) {
                    minIndex = j;
                }
            }

            // Intercambiar elementos
            Asignación temp = asigna.get(minIndex);
            asigna.set(minIndex, asigna.get(i));
            asigna.set(i, temp);
        }

        // Mostrar la lista ordenada
        JOptionPane.showMessageDialog(null,"Lista ordenada por placa:");
        for (Asignación asignacion : asigna) {
            System.out.println(asignacion.info());
        }
    }

    //Metodo diseñado para buscar una asignación esécifica dependeindo de la placa del vehiculo mostrando toda la información.
    public void buscarPorPlaca(String placa) {
        boolean encontrado = false;
        if (asigna == null || asigna.isEmpty()) {
            JOptionPane.showMessageDialog(null,"La lista está vacía...");
            return;
        }
        for (Asignación asignacion : asigna) {
            if (asignacion.getVehiculo().getPlaca().equalsIgnoreCase(placa)) {
                JOptionPane.showMessageDialog(null,"Asignacion encontrada"+asignacion.info());

                encontrado = true;
                return;
            }
        }
        if (!encontrado) {
            JOptionPane.showMessageDialog(null,"No se encontro la placa: " + placa);
        }
    }
}

package edu.ucompensar.codigo;

import java.util.Iterator;
import javax.swing.JOptionPane;

public class Conductores {

    //Creación de los atributos y una instancia de la clase gestorVehiculo (gv).
    private String Nombre;
    private int Edad;
    private String Identificacion;
    private boolean Disponibilidad;
    public gestorVehiculos gv = new gestorVehiculos();

    //Crecaión del constructor.
    public Conductores(String Nombre, int Edad, String Identificacion, boolean Disponibilidad) {

        this.Nombre = Nombre;
        this.Edad = Edad;
        this.Identificacion = Identificacion;
        this.Disponibilidad = Disponibilidad;

    }

    //Getters y setters de los diferentes atributos.
    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getEdad() {
        return Edad;
    }

    public void setEdad(int Edad) {
        this.Edad = Edad;
    }

    public String getIdentificacion() {
        return Identificacion;
    }

    public void setIdentificacion(String Identificacion) {
        this.Identificacion = Identificacion;
    }

    public boolean getDisponibilidad() {
        return Disponibilidad;
    }

    public void setDisponibilidad(boolean Disponible) {
        this.Disponibilidad = Disponible;
    }

    //Se agregara el nuevo objeto conductor a la lista cond ubicada en la clase gestorInventario (gv).
    public void agregarConductores(Conductores conductor) {
        gv.cond.add(conductor);
    }

    //Se elimina el objeto conductor dependiendo de la identificación de la lista cond ubicada en la clase gestorInventario (gv) a travez de un Iterator para recorrer la lista     con algunos condicionales siempre y cuando hayan valores a eliminar.
    public void eliminarConductor(String identificacion) {
        if (gv.cond.isEmpty()) {
            System.out.println("No hay información en la lista...");
            return;
        }
        Iterator<Conductores> iter = gv.cond.iterator();
        while (iter.hasNext()) {
            Conductores con = iter.next();
            if (con.getIdentificacion().equals(identificacion)) {
                iter.remove();
                JOptionPane.showMessageDialog(null,"Conductor eliminado...");
                return; 
            }
        }
        JOptionPane.showMessageDialog(null,"El conductor no fue encontrado...");
    }

    //Muestra toda la informacion de los conductores almacenada en la lista cond ubicada en la clase gestorInventario (gv) siempre y cuando hayan valores a mostrar.
    public void mostrarTodasLosConductores() {
        if (gv.cond.isEmpty()) {
            System.out.println("No hay conductores disponibles.");
        } else {
            System.out.println("Conductores disponibles:");
            for (Conductores conductor : gv.cond) {
                System.out.println("Nombre: " + conductor.getNombre() + ", Edad:" + conductor.getEdad() + ", Identificacion: " + conductor.getIdentificacion());
                System.out.println("------------------------------------------------------------");
            }
        }
    }
}

package edu.ucompensar.codigo;

import java.util.Iterator;
import javax.swing.JOptionPane;

public class Productos {

    //Creación de los atributos y una instancia de la clase gestorVehiculo (gv).
    private String Marca;
    private String Categoria;
    public gestorVehiculos gv = new gestorVehiculos();

    //Crecaión del constructor.
    public Productos(String marca, String categoria) {

        this.Marca = marca;
        this.Categoria = categoria;

    }

    //Getters y setters de los diferentes atributos.
    public String getMarca() {
        return Marca;
    }

    public void setMarca(String Marca) {
        this.Marca = Marca;
    }

    public String getCategoria() {
        return Categoria;
    }

    public void setNombre(String Categoria) {
        this.Categoria = Categoria;
    }

    //Se agregara el nuevo objeto producto a la lista prod ubicada en la clase gestorInventario (gv).
    public void agregarProducto(Productos producto) {
        gv.prod.add(producto);
    }

    //Se elimina el objeto producto dependiendo de la marac de la lista prod ubicada en la clase gestorInventario (gv) a travez de un Iterator para recorrer la lista con           algunos condicionales siempre y cuando hayan valores a eliminar.
    public void eliminarProducto(String Marca) {
        boolean eliminado = false;
        Iterator<Productos> iter = gv.prod.iterator();
        while (iter.hasNext()) {
            Productos pro = iter.next();
            if (pro.getMarca().equals(Marca)) {
                eliminado = true;
                iter.remove();
                JOptionPane.showMessageDialog(null,"Producto eliminado...");
                return;
            }
        }

        if (!eliminado) {
            JOptionPane.showMessageDialog(null,"El producto no fue encontrado...");
        }
    }

    //Muestra toda la informacion de los productos almacenada en la lista prod ubicada en la clase gestorInventario (gv) siempre y cuando hayan valores a mostrar.
    public void mostrarTodosLosProductos() {
        if (gv.prod.isEmpty()) {
            System.out.println("No hay conductores disponibles.");
        } else {
            System.out.println("Conductores disponibles:");
            for (Productos producto : gv.prod) {
                System.out.println("Marca: " + producto.getMarca() + ", Categoria:" + producto.getCategoria());
                System.out.println("------------------------------------------------------------");
            }
        }
    }
}

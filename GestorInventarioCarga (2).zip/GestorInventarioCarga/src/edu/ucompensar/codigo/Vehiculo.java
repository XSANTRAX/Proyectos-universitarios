package edu.ucompensar.codigo;

//Se crea una clase abstracta llamada Vehiculo
abstract public class Vehiculo {

    //Creación de los atributos
    private String Marca;
    private String Modelo;
    private int Capacidad;
    private int Ejes;
    private String Placa;
    private boolean Disponibilidad;

    //Creación del constructor
    public Vehiculo(String Marca, String Modelo, int Capacidad, int Ejes, String Placa, boolean Disponible) {

        this.Marca = Marca;
        this.Modelo = Modelo;
        this.Capacidad = Capacidad;
        this.Ejes = Ejes;
        this.Placa = Placa;
        this.Disponibilidad = Disponible;
        
    }

    //Getters y setters de los diferentes atributos.
    public String getMarca() {
        return Marca;
    }
    public void setMarca(String Marca) {
        this.Marca = Marca;
    }
    
    public String getModelo() {
        return Modelo;
    }
    public void setModelo(String Modelo) {
        this.Modelo = Modelo;
    }
    
    public int getCapacidad() {
        return Capacidad;
    }
    public void setCapacidad(int Capacidad) {
        this.Capacidad = Capacidad;
    }
    
    public int getEjes() {
        return Ejes;
    }
    public void setEjes(int Ejes) {
        this.Ejes = Ejes;
    }
    
    public String getPlaca() {
        return Placa;
    }
    public void setPlaca(String Placa) {
        this.Placa = Placa;
    }
    
    public boolean getDisponibilidad() {
        return Disponibilidad;
    }
    public void setDisponibilidad(boolean Disponible) {
        this.Disponibilidad = Disponible;
    }
    
    //Creación de metodos abstractos
    abstract void agregarVehiculo(Vehiculo vehiculo);
    abstract void eliminarVehiculo(String placa);
    abstract void mostrarTodosLosVehiculos();
}

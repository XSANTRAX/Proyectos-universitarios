package edu.ucompensar.codigo;

import java.util.Iterator;
import javax.swing.JOptionPane;

//La clase Tractomula extiende de la clase Vehiculo heredando sus atributos y metodos.
public class Tractomula extends Vehiculo {

     //Creación de una instancia de la clase gestorVehiculo (gv).
    public gestorVehiculos gv = new gestorVehiculos();

    //Se hereda el constructor de la clase Vehiculo.
    public Tractomula(String Marca, String Modelo, int Capacidad, int Ejes, String Placa, boolean disponible) {
        super(Marca, Modelo, Capacidad, Ejes, Placa, disponible);
    }

    //Se agregara el nuevo objeto tractomula a la lista veh ubicada en la clase gestorInventario (gv).
    @Override
    public void agregarVehiculo(Vehiculo tractomula) {
        gv.veh.add(tractomula);
    }

    //Se elimina el objeto tyractomula dependiendo de la placa de la lista veh ubicada en la clase gestorInventario (gv) a travez de un Iterator para recorrer la lista con            algunos condicionales siempre y cuando hayan valores a eliminar.
    @Override
    public void eliminarVehiculo(String placa) {
        boolean eliminado = false;
        Iterator<Vehiculo> iter = gv.veh.iterator();
        while (iter.hasNext()) {
            Vehiculo tracto = iter.next();
            if (tracto.getPlaca().equals(placa)) {
                eliminado = true;
                iter.remove();
                JOptionPane.showMessageDialog(null,"Vehiculo eliminado...");
                return;
            }
        }

        if (!eliminado) {
            JOptionPane.showMessageDialog(null,"El vehiculo no fue encontrado...");
        }

    }

    //Muestra toda la informacion de los vehiculos mas especificamente la de las tractomulas almacenada en la lista veh ubicada en la clase gestorInventario (gv) siempre y           cuando hayan valores a mostrar.
    @Override
    void mostrarTodosLosVehiculos() {
        if (gv.veh.isEmpty()) {
            System.out.println("No hay vehiculos disponibles.");
            return;
        } else {
            System.out.println("Tractomulas disponibles:");
            boolean hayVolquetas = false;
            for (Vehiculo tractomula : gv.veh) {
                if (tractomula.getEjes() >= 5) {
                    System.out.println("Marca: " + tractomula.getMarca() + ", Modelo: " + tractomula.getModelo() + ", Capacidad: " + tractomula.getCapacidad() + ", Ejes: " + tractomula.getEjes() + ", Placa: " + tractomula.getPlaca() + ", Disponibilidad: " + tractomula.getDisponibilidad());
                    System.out.println("---------------------------------------------------------------");
                    hayVolquetas = true;
                }
            }
            if (!hayVolquetas) {
                System.out.println("No hay tractomulas disponibles.");
            }
        }
    }
}


package edu.ucompensar.codigo;

//Creacion de una interfaz llamada calcularTarifa
public interface calcularTarifa {
    
    //Creación de las diferentes constantes a usar.
    int ejes2 = 80000;
    int ejes3 = 120000;
    int ejes4 = 160000;
    int ejes5 = 280000;
    int ejes6 = 400000;
    
    // Creación del método calculaCargaTarifa para sobrescribirlo en la clase gestorVehiculo
    int calculaCargaTarifa(String Placa, int toneladas);
}

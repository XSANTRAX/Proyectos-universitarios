package edu.ucompensar.codigo;

public class Asignación {

    //Creación de los atributos que se necesitan para la asignación.
    private Vehiculo vehiculo;
    private Conductores conductor;
    private Productos producto;
    private int toneladas;
    private int tarifa;

    //Creación del constructor
    public Asignación(Vehiculo vehiculo, Conductores conductor, Productos producto, int toneladas, int tarifa) {

        this.vehiculo = vehiculo;
        this.conductor = conductor;
        this.producto = producto;
        this.toneladas = toneladas;
        this.tarifa = tarifa;

    }

    //Getters y setters de los diferentes atributos.
    public Vehiculo getVehiculo() {
        return vehiculo;
    }

    public void setVehiculo(Vehiculo vehiculo) {
        this.vehiculo = vehiculo;
    }
    
    public Conductores getConductor() {
        return conductor;
    }
    public void setConductor(Conductores conductor) {
        this.conductor = conductor;
    }
    
    public Productos getProducto() {
        return producto;
    }
    public void setProducto(Productos producto) {
        this.producto = producto;
    }
    
    public int getToneladas() {
        return toneladas;
    }
    public void setToneladas(int Toneladas) {
        this.toneladas = Toneladas
;    }
    
    public int getTarifa() {
        return tarifa;
    }
    public void setTarifa(int Tarifa) {
        this.tarifa = Tarifa;
    }

    //Creación de un metodo llamado info para definir como se vera la información de las diferentes asignaciones que se realicen
    public String info() {
        return "Placa del vehiculo: " + vehiculo.getPlaca() + "\n Conductor: " + conductor.getNombre() + "\n Producto: " + producto.getMarca() + "\n Toneladas: " + getToneladas() + "\n Tarifa: " + getTarifa();
    }
}

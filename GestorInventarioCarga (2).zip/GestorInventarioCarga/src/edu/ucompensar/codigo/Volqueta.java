package edu.ucompensar.codigo;

import java.util.Iterator;
import javax.swing.JOptionPane;

//La clase Volqueta extiende de la clase Vehiculo heredando sus atributos y metodos.
public class Volqueta extends Vehiculo {
    
    //Creación de una instancia de la clase gestorVehiculo (gv).
    public gestorVehiculos gv = new gestorVehiculos();

    //Se hereda el constructor de la clase Vehiculo.
    public Volqueta(String Marca, String Modelo, int Capacidad, int Ejes, String Placa, boolean disponible) {
        super(Marca, Modelo, Capacidad, Ejes, Placa, disponible);
    }
    
    //Se agregara el nuevo objeto volqueta a la lista veh ubicada en la clase gestorInventario (gv).
    @Override
    public void agregarVehiculo(Vehiculo volqueta) {
        gv.veh.add(volqueta);
    }

    //Se elimina el objeto volqueta dependiendo de la placa de la lista veh ubicada en la clase gestorInventario (gv) a travez de un Iterator para recorrer la lista con            algunos condicionales siempre y cuando hayan valores a eliminar.
    @Override
    public void eliminarVehiculo(String placa) {
        if (gv.veh.isEmpty()) {
            JOptionPane.showMessageDialog(null,"No hay información en la lista...");
            return;
        }
        Iterator<Vehiculo> iter = gv.veh.iterator();
        while (iter.hasNext()) {
            Vehiculo volque = iter.next();
            if (volque.getPlaca().equals(placa)) {
                iter.remove();
                JOptionPane.showMessageDialog(null,"Vehiculo eliminado...");
                return;
            }
        }
        JOptionPane.showMessageDialog(null,"El vehiculo no fue encontrado...");

    }

    //Muestra toda la informacion de los vehiculos mas especificamente la de las volquetas almacenada en la lista veh ubicada en la clase gestorInventario (gv) siempre y           cuando hayan valores a mostrar.
    @Override
    public void mostrarTodosLosVehiculos() {
        if (gv.veh.isEmpty()) {
            System.out.println("No hay vehiculos disponibles.");
            return;
        } else {
            System.out.println("Volquetas disponibles:");
            boolean hayVolquetas = false;
            for (Vehiculo volqueta : gv.veh) {
                if (volqueta.getEjes() <= 4) {
                    System.out.println("Marca: " + volqueta.getMarca() + ", Modelo: " + volqueta.getModelo() + ", Capacidad: " + volqueta.getCapacidad() + ", Ejes: " + volqueta.getEjes() + ", Placa: " + volqueta.getPlaca() + ", Disponibilidad: " + volqueta.getDisponibilidad());
                    System.out.println("---------------------------------------------------------------");
                    hayVolquetas = true;
                }
            }
            if (!hayVolquetas) {
                System.out.println("No hay volquetas disponibles.");
            }
        }
    }
}

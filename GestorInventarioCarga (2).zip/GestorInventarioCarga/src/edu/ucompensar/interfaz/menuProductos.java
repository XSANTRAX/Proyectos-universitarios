
package edu.ucompensar.interfaz;

import edu.ucompensar.codigo.Conductores;
import edu.ucompensar.codigo.Productos;
import edu.ucompensar.codigo.gestorVehiculos;
import java.awt.BorderLayout;//Libreria que permite administrar el diseño que define un contenedor en cinco areas
import java.awt.Color;//Libreria que permite usar colores para textos o botones
import java.awt.Graphics; //libreria para almacenar toda la informacion del estado de una imagen
import javax.swing.ImageIcon; // Libreria para mostrar imagenes como iconos
import java.awt.Dimension; //Libreria almacena el ancho y alto de una imagen para poder modificarla
import java.awt.Image; //Libreria para poder ajustar la imagen al tamaño del objeto
import javax.swing.JPanel; //Libreria que permite trabajar la parte grafica del JFrame como un JPanel
import java.awt.Font; //Libreria que permite configurar la fuente
import java.awt.GridBagConstraints; //Libreria que se usa junto con GridBagLayout para poder definir la posicion, tamaño de los componentes
import java.awt.GridBagLayout; //Libreria que permite administrar el diseño de los componentes para ubicarlos en una cuadricula
import java.awt.Insets; //Libreria que define un espaciado de los componentes del layout
import javax.swing.BorderFactory; //Libreria que proporciona metodos para crear bordes decorativos
import javax.swing.JButton;//Libreria para poder crear botones
import javax.swing.JFrame;//Libreria que permite tener la ventana principal
import javax.swing.JLabel;//Libreria que permite crear componentes que tienen texto
import javax.swing.JOptionPane; //Libreria que permite usar cuadros de dialogo emergentes ya sea para mostrar o ingresar datos
import javax.swing.SwingConstants;//Libreria que contiene constantes para alinear textos o componentes
import javax.swing.SwingUtilities;//Libreria que permite ejecutar codigo de forma segura para la GUI


public class menuProductos extends javax.swing.JFrame {

    Productos produ = new Productos(null, null);
    gestorVehiculos gestor = new gestorVehiculos();
    fondoPanel fondo = new fondoPanel();
    private JButton botonMostrar;
    private JButton botonAgregar;
    private JButton botonVolver;
    private JButton botonEliminar;
    private JButton botonBuscar;
    
    public menuProductos() {
        produ.gv = gestor;
        
        setTitle("Menu de productos");
        this.setContentPane(fondo);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1440, 1080);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());
        
        JPanel panelBotones = new JPanel(new GridBagLayout());
        panelBotones.setOpaque(false);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 0, 15, 0);  // Espaciado entre los botones
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        Font fuenteBoton = new Font("Arial", Font.BOLD, 18);
        
        
        //JLabel titulo con un contenedor
        JLabel titulo = new JLabel("Menu productos");
        titulo.setFont(new Font("Arial", Font.BOLD, 32));
        titulo.setForeground(Color.WHITE);
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridy = 0;
        panelBotones.add(titulo, gbc);
        JPanel panelTitulo = new JPanel();
        panelTitulo.setOpaque(true);
        panelTitulo.setBackground(new Color(0, 0, 0, 150)); 
        panelTitulo.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2)); 
        panelTitulo.setLayout(new BorderLayout());
        panelTitulo.add(titulo, BorderLayout.CENTER);
        panelTitulo.setPreferredSize(new Dimension(600, 60));
        gbc.gridy = 0;
        panelBotones.add(panelTitulo, gbc);
        
        GridBagConstraints gbcFrame = new GridBagConstraints();
        gbcFrame.anchor = GridBagConstraints.CENTER;
        add(panelBotones, gbcFrame);
        
        //Botones
        
        //Se crea los botones con sus respectivos eventos, fuente y color tanto del fondo como de la letra, ademas del numero jerarquico de ubicacion en el Grid
        
        botonMostrar = new JButton("Mostrar Productos");
        botonMostrar.addActionListener(e -> mostrarProductos());
        botonMostrar.setFont(fuenteBoton);
        botonMostrar.setBackground(Color.decode("#4CAF50")); 
        botonMostrar.setForeground(Color.WHITE);
        gbc.gridy = 1;
        add(botonMostrar,gbc);
        
        botonAgregar = new JButton("Agregar Producto");
        botonAgregar.addActionListener(e -> agregarProductos());
        botonAgregar.setFont(fuenteBoton);
        botonAgregar.setBackground(Color.decode("#4CAF50")); 
        botonAgregar.setForeground(Color.WHITE);
        gbc.gridy = 2;
        add(botonAgregar,gbc);
        
        botonEliminar = new JButton("Eliminar Producto");
        botonEliminar.addActionListener(e -> eliminarProducto());
        botonEliminar.setFont(fuenteBoton);
        botonEliminar.setBackground(Color.decode("#4CAF50")); 
        botonEliminar.setForeground(Color.WHITE);
        gbc.gridy = 3;
        add(botonEliminar,gbc);
        
        botonBuscar = new JButton("Buscar Producto");
        botonBuscar.addActionListener(e -> buscarProducto());
        botonBuscar.setFont(fuenteBoton);
        botonBuscar.setBackground(Color.decode("#4CAF50")); 
        botonBuscar.setForeground(Color.WHITE);
        gbc.gridy = 4;
        add(botonBuscar,gbc);
        
        botonVolver = new JButton("Volver");
        botonVolver.addActionListener(e -> volver());
        botonVolver.setFont(fuenteBoton);
        botonVolver.setBackground(Color.decode("#F44336")); 
        botonVolver.setForeground(Color.WHITE);
        gbc.gridy = 5;
        add(botonVolver,gbc);
        
        

    }
    //evento del boton volver el cual cierra la ventana de menuProductos sin cerrar el programa
    private void volver(){
        dispose();
    }
    //evento del boton Mostrar productos el cual abre el JFrame tablaProductos para mirar la tabla donde estan todos los productos
    private void mostrarProductos(){
      tablaProductos tablaProductosFrame = new tablaProductos();
      tablaProductosFrame.setVisible(true);
    }
    //evento del boton Agregar producto donde pide la marca y categoria para luego agregarlo a la lista
    private void agregarProductos(){
        String marca = JOptionPane.showInputDialog(this, "Ingrese la marca del producto: ");
            if (marca == null || marca.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "El marca no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        String categoria = JOptionPane.showInputDialog(this, "Ingrese la categoria del producto: ");
            if (categoria == null || categoria.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "El modelo no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        Productos product = new Productos(marca, categoria);
        gestorVehiculos.prod.add(product);
        JOptionPane.showMessageDialog(this, "Producto agregado");
    }
    
    //evento del boton Eliminar producto el cual pide al usuario la marca del producto para despues eliminarlo con el metodo eliminarProducto
    private void eliminarProducto(){
        String marca = JOptionPane.showInputDialog(this, "Ingrese la marca del producto: ");
            if (marca == null || marca.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "La placa no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
                return;  
            }
            produ.eliminarProducto(marca);
    }
    
    //evento del boton Buscar producto el cual pide al usuario la marca para poder usar el metodo buscarProducto y devolver la informacion del producto
    private void buscarProducto(){
        String marca = JOptionPane.showInputDialog(this, "Ingrese la marca del producto: ");
            if (marca == null || marca.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "La marca no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
                return;  
            }
            Productos prod = gestor.buscarProducto(marca);
            JOptionPane.showMessageDialog(this,"Marca: "+prod.getMarca()+"\nCategoria: "+prod.getCategoria());
    }
    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

    //Clase donde se define la imagen del fondo del JFrame
    class fondoPanel extends JPanel{
        private Image imagen;
        @Override
        public void paint (Graphics g){
            imagen = new ImageIcon(getClass().getResource("/imagenes/productos_almacen.jpg")).getImage();
            g.drawImage(imagen, 0,0 , getWidth(),getHeight(), this);
            setOpaque(false);
            super.paint(g);
        }
    }
}

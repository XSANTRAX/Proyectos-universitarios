
package edu.ucompensar.interfaz;

import edu.ucompensar.codigo.Tractomula;
import edu.ucompensar.codigo.Vehiculo;
import edu.ucompensar.codigo.Volqueta;
import edu.ucompensar.codigo.gestorVehiculos;
import java.awt.BorderLayout;//Libreria que permite administrar el diseño que define un contenedor en cinco areas
import java.awt.Color;//Libreria que permite usar colores para textos o botones
import java.awt.Graphics; //libreria para almacenar toda la informacion del estado de una imagen
import javax.swing.ImageIcon; // Libreria para mostrar imagenes como iconos
import java.awt.Dimension; //Libreria almacena el ancho y alto de una imagen para poder modificarla
import java.awt.Image; //Libreria para poder ajustar la imagen al tamaño del objeto
import javax.swing.JPanel; //Libreria que permite trabajar la parte grafica del JFrame como un JPanel
import java.awt.Font; //Libreria que permite configurar la fuente
import java.awt.GridBagConstraints; //Libreria que se usa junto con GridBagLayout para poder definir la posicion, tamaño de los componentes
import java.awt.GridBagLayout; //Libreria que permite administrar el diseño de los componentes para ubicarlos en una cuadricula
import java.awt.Insets; //Libreria que define un espaciado de los componentes del layout
import javax.swing.BorderFactory; //Libreria que proporciona metodos para crear bordes decorativos
import javax.swing.JButton;//Libreria para poder crear botones
import javax.swing.JFrame;//Libreria que permite tener la ventana principal
import javax.swing.JLabel;//Libreria que permite crear componentes que tienen texto
import javax.swing.JOptionPane; //Libreria que permite usar cuadros de dialogo emergentes ya sea para mostrar o ingresar datos
import javax.swing.SwingConstants;//Libreria que contiene constantes para alinear textos o componentes
import javax.swing.SwingUtilities;//Libreria que permite ejecutar codigo de forma segura para la GUI


public class menuVehiculos extends javax.swing.JFrame {
        
    Volqueta vol = new Volqueta(null, null, 0, 0, null, false);
    Tractomula tract = new Tractomula(null, null, 0, 0, null, false);
    gestorVehiculos gestor = new gestorVehiculos();
    fondoPanel fondo = new fondoPanel();
    private JButton botonMostrar;
    private JButton botonAgregar;
    private JButton botonEliminar;
    private JButton botonVolver;
    private JButton botonBuscar;
 
    public menuVehiculos() {
        vol.gv = gestor;
        tract.gv = gestor;
        
        setTitle("Menu de vehiculos");
        this.setContentPane(fondo);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1440, 1080);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());
        
        JPanel panelBotones = new JPanel(new GridBagLayout());
        panelBotones.setOpaque(false);
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(15, 0, 15, 0);  // Espaciado entre los botones
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        Font fuenteBoton = new Font("Arial", Font.BOLD, 18);
       
        //JLabel titulo con un contenedor y un grid para alinear el titulo con los botones
        
        JLabel titulo = new JLabel("Menu vehiculos");
        titulo.setFont(new Font("Arial", Font.BOLD, 32));
        titulo.setForeground(Color.WHITE);
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridy = 0;
        panelBotones.add(titulo, gbc);
        JPanel panelTitulo = new JPanel();
        panelTitulo.setOpaque(true);
        panelTitulo.setBackground(new Color(0, 0, 0, 150)); 
        panelTitulo.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2)); 
        panelTitulo.setLayout(new BorderLayout());
        panelTitulo.add(titulo, BorderLayout.CENTER);
        panelTitulo.setPreferredSize(new Dimension(600, 60));
        gbc.gridy = 0;
        panelBotones.add(panelTitulo, gbc);
        
        GridBagConstraints gbcFrame = new GridBagConstraints();
        gbcFrame.anchor = GridBagConstraints.CENTER;
        add(panelBotones, gbcFrame);
        
        
        //Se crea el boton para mostrar conductores y se le da un evento
        botonMostrar = new JButton("Mostrar Vehiculos");
        botonMostrar.addActionListener(e -> mostrarVehiculos());
        botonMostrar.setFont(fuenteBoton);
        botonMostrar.setBackground(Color.decode("#4CAF50")); 
        botonMostrar.setForeground(Color.WHITE);
        gbc.gridy = 1;
        add(botonMostrar,gbc);
        
        botonAgregar = new JButton("Agregar Vehiculo");
        botonAgregar.addActionListener(e -> agregarVehiculo());
        botonAgregar.setFont(fuenteBoton);
        botonAgregar.setBackground(Color.decode("#4CAF50")); 
        botonAgregar.setForeground(Color.WHITE);
        gbc.gridy = 2;
        add(botonAgregar,gbc);
        
        botonEliminar = new JButton("Eliminar Vehiculo");
        botonEliminar.addActionListener(e -> eliminarVehiculo());
        botonEliminar.setFont(fuenteBoton);
        botonEliminar.setBackground(Color.decode("#4CAF50")); 
        botonEliminar.setForeground(Color.WHITE);
        gbc.gridy = 3;
        add(botonEliminar,gbc);
        
        botonBuscar = new JButton("Buscar Vehiculo");
        botonBuscar.addActionListener(e -> buscarVehiculo());
        botonBuscar.setFont(fuenteBoton);
        botonBuscar.setBackground(Color.decode("#4CAF50")); 
        botonBuscar.setForeground(Color.WHITE);
        gbc.gridy = 4;
        add(botonBuscar,gbc);
        
        botonVolver = new JButton("Volver");
        botonVolver.addActionListener(e -> volver());
        botonVolver.setFont(fuenteBoton);
        botonVolver.setBackground(Color.decode("#F44336")); 
        botonVolver.setForeground(Color.WHITE);
        gbc.gridy = 5;
        add(botonVolver,gbc);
        
        

    }
    //evento del boton volver el cual cierra la ventana de menuVehiculos sin cerrar el programa
    private void volver(){
        dispose();
    }
    
    //evento del boton Buscar vehiculo el cual pide al usuario el tipo de vehiculo, ya sea volqueta o tractomula y despues la placa para poder usar el metodo buscarVehiculo y devolver la informacion de vehiculo
    private void buscarVehiculo(){
        String tipe = JOptionPane.showInputDialog(this, "Que tipo de vehiculo desea buscar:"
                + "\n1. Volqueta"
                + "\n2. Tractomula");
        int tipo = Integer.parseInt(tipe); 
        String placa = JOptionPane.showInputDialog(this, "Ingrese la placa del vehiculo: ");
            if (placa == null || placa.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "La placa no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
                return;  
            }
            
        if(tipo == 1){
            Vehiculo volquet = gestor.buscarVehiculo(placa);
            JOptionPane.showMessageDialog(this,"Marca: "+volquet.getMarca()+"\n Modelo: "+volquet.getModelo()+"\n Capacidad: "+volquet.getCapacidad()+" toneladas \nEjes: "+volquet.getEjes()+"\n Placa: "+volquet.getPlaca());

        }
        if (tipo == 2){
            Vehiculo tracto = gestor.buscarVehiculo(placa);
            JOptionPane.showMessageDialog(this,"Marca: "+tracto.getMarca()+", Modelo: "+tracto.getModelo()+", Capacidad "+tracto.getCapacidad()+" toneladas, Ejes: "+tracto.getEjes()+", Placas: "+tracto.getPlaca());
        }
    }
    
    //evento del boton Eliminar vehiculo el cual pide al usuario el tipo de vehiculo y la placa para despues eliminarlo con el metodo eliminarVehiculo 
    private void eliminarVehiculo(){
        String tipe = JOptionPane.showInputDialog(this, "Que tipo de vehiculo desea eliminar:"
                + "\n1. Volqueta"
                + "\n2. Tractomula");
        int tipo = Integer.parseInt(tipe); 
        String placa = JOptionPane.showInputDialog(this, "Ingrese la placa del vehiculo: ");
            if (placa == null || placa.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "La placa no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
                return;  
            }
            
        if(tipo == 1){
            vol.eliminarVehiculo(placa);
        }
        if (tipo == 2){
            tract.eliminarVehiculo(placa);
        }
        
    }
    
    
    //evento del boton Mostrar vehiculos el cual abre el JFrame tablaVehiculos para mirar la tabla donde estan todos los vehiculos
    private void mostrarVehiculos(){
        tablaVehiculos tablaVehiculosFrame = new tablaVehiculos();
        tablaVehiculosFrame.setVisible(true);
    }
    
    //evento del boton Agregar vehiculo donde pide el tipo de vehiculo y luego la marca, modelo, capacidad, ejes y placa para luego guardarlo en la lista
    private void agregarVehiculo(){
        String tipe = JOptionPane.showInputDialog(this, "Que tipo de vehiculo desea ingresar:"
                + "\n1. Volqueta"
                + "\n2. Tractomula");
        int tipo = Integer.parseInt(tipe); 
        if(tipo == 1){
            String marca = JOptionPane.showInputDialog(this, "Ingrese la marca del vehiculo: ");
            if (marca == null || marca.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "El marca no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String modelo = JOptionPane.showInputDialog(this, "Ingrese el modelo del vehiculo: ");
            if (modelo == null || modelo.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "El modelo no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String capacidad = JOptionPane.showInputDialog(this, "Ingrese la capacidad en toneladas del vehiculo: ");
                int capacida = Integer.parseInt(capacidad);
            if (capacidad == null || capacidad.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "La capacidad no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String ejes = JOptionPane.showInputDialog(this, "Ingrese los ejes del vehiculo: ");
            int eje = Integer.parseInt(ejes);
            if (ejes == null || ejes.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "Los ejes no pueden estar en vacío.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String placa = JOptionPane.showInputDialog(this, "Ingrese la placa del vehiculo: ");
            if (placa == null || placa.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "La placa no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
                return;  
            }
            Vehiculo volqueta = new Volqueta(marca,modelo,capacida,eje,placa,true);
            gestorVehiculos.veh.add(volqueta);
            JOptionPane.showMessageDialog(this, "Vehiculo tipo volqueta agregada");
            
        }if (tipo == 2){
            String marca = JOptionPane.showInputDialog(this, "Ingrese la marca del vehiculo: ");
            if (marca == null || marca.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "La marca no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String modelo = JOptionPane.showInputDialog(this, "Ingrese el modelo del vehiculo: ");
            if (modelo == null || modelo.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "El modelo no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String capacidad = JOptionPane.showInputDialog(this, "Ingrese la capacidad del vehiculo: ");
                int capacida = Integer.parseInt(capacidad);
            if (capacidad == null || capacidad.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "La capacidad no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String ejes = JOptionPane.showInputDialog(this, "Ingrese los ejes del vehiculo: ");
            int eje = Integer.parseInt(ejes);
            if (ejes == null || ejes.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "Los ejes no puede estar vacíos.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            String placa = JOptionPane.showInputDialog(this, "Ingrese la placa del vehiculo: ");
            if (placa == null || placa.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "La placa no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
                
            }
            Vehiculo tractomula = new Tractomula(marca,modelo,capacida,eje,placa,true);
            gestorVehiculos.veh.add(tractomula);
            JOptionPane.showMessageDialog(this, "Vehiculo tipo tractomula agregada");
        }

        
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents



    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

    //Clase donde se define la imagen del fondo del JFrame
    class fondoPanel extends JPanel{
        private Image imagen;
        @Override
        public void paint (Graphics g){
            imagen = new ImageIcon(getClass().getResource("/imagenes/render-3d-de-una-flota-de-vehiculos-de-entrega.jpg")).getImage();
            g.drawImage(imagen, 0,0 , getWidth(),getHeight(), this);
            setOpaque(false);
            super.paint(g);
        }
    }
}


package edu.ucompensar.interfaz;

import edu.ucompensar.codigo.Asignación;
import edu.ucompensar.codigo.gestorVehiculos;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class tablaAsignaciones extends javax.swing.JFrame {

    gestorVehiculos gestor = new gestorVehiculos();
    private JTable tabla;
    private JButton botonMostrar;
    private JButton botonOrdenar;
    private JButton botonVolver;

    public tablaAsignaciones() {
        //Titulo del frame
    setTitle("Tabla de asignacion");
    setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    setLayout(new java.awt.BorderLayout());
    setSize(1440, 1080);
    setLocationRelativeTo(null);
    
    //Se crea el boton para mostrar conductores y se le da un evento
    botonMostrar = new JButton("Mostrar asignaciones");
    botonMostrar.addActionListener(e -> mostrarAsignaciones());
        
        
    botonVolver = new JButton("Volver");
    botonVolver.addActionListener(e -> volver());
    
    botonOrdenar = new JButton("Ordenar asignaciones");
    botonOrdenar.addActionListener(e -> ordenarAsignaciones());    

    //L
    tabla = new JTable(new DefaultTableModel(new Object[]{"Placa","Conductor","Producto","toneladas","Tarifa"}, 0));
    JScrollPane scrollPane = new JScrollPane(tabla);

    add(scrollPane, java.awt.BorderLayout.CENTER);
    add(botonMostrar, java.awt.BorderLayout.WEST);
    add(botonVolver, java.awt.BorderLayout.SOUTH);
    add(botonOrdenar, java.awt.BorderLayout.EAST);
    
        setSize(400, 300);
        setVisible(true);
    }
    private void volver(){
        dispose();
    }
    
    //arreglar este metodo
    private void mostrarAsignaciones() {
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
        modelo.setRowCount(0);
        
        for (Asignación asignas : gestorVehiculos.asigna) {
            modelo.addRow(new Object[] {asignas.getVehiculo().getPlaca(),asignas.getConductor().getNombre(), asignas.getProducto().getMarca(), asignas.getVehiculo().getCapacidad() ,asignas.getTarifa()});
        }
    }
    
    private void ordenarAsignaciones() {
        gestor.ordenarAsignacionesSeleccion();
    }
    
    


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents


    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}

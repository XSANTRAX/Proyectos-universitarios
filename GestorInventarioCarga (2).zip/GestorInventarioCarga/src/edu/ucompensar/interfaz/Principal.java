
package edu.ucompensar.interfaz;

import Sonido.Sonido;
import java.awt.BorderLayout;//Libreria que permite administrar el diseño que define un contenedor en cinco areas
import java.awt.Color;//Libreria que permite usar colores para textos o botones
import java.awt.Graphics; //libreria para almacenar toda la informacion del estado de una imagen
import javax.swing.ImageIcon; // Libreria para mostrar imagenes como iconos
import java.awt.Dimension; //Libreria almacena el ancho y alto de una imagen para poder modificarla
import java.awt.Image; //Libreria para poder ajustar la imagen al tamaño del objeto
import javax.swing.JPanel; //Libreria que permite trabajar la parte grafica del JFrame como un JPanel
import java.awt.Font; //Libreria que permite configurar la fuente
import java.awt.GridBagConstraints; //Libreria que se usa junto con GridBagLayout para poder definir la posicion, tamaño de los componentes
import java.awt.GridBagLayout; //Libreria que permite administrar el diseño de los componentes para ubicarlos en una cuadricula
import java.awt.Insets; //Libreria que define un espaciado de los componentes del layout
import javax.swing.BorderFactory; //Libreria que proporciona metodos para crear bordes decorativos
import javax.swing.JButton;//Libreria para poder crear botones
import javax.swing.JFrame;//Libreria que permite tener la ventana principal
import javax.swing.JLabel;//Libreria que permite crear componentes que tienen texto
import javax.swing.SwingConstants;//Libreria que contiene constantes para alinear textos o componentes
import javax.swing.SwingUtilities;//Libreria que permite ejecutar codigo de forma segura para la GUI


public class Principal extends javax.swing.JFrame {

    fondoPanel fondo = new fondoPanel();
    private JButton botonVehiculos;
    private JButton botonConductores;
    private JButton botonProductos;
    private JButton botonAsignacion;
    private JButton botonSalir;
    

    public Principal() {
        //Nombrando al JFrame, agregandole ademas un pane donde ira la imagen, se le agrego una ajecucion de cerrar la pestaña pero no el sistema y el tamaño sera de 1440 x 1080
        //ademas este no se ubicara en ningun lado en especifico de la pantalla y se le agrega el grid
        this.setContentPane(fondo);
        setTitle("Menú Principal");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1440, 1080);
        setLocationRelativeTo(null);
        setLayout(new GridBagLayout());
        
        //Se crea un panel para poder ubicar los botones de forma ordenada
        JPanel panelBotones = new JPanel(new GridBagLayout());
        panelBotones.setOpaque(false);
        
        
        Sonido musica = new Sonido();
        musica.reproducir("srcs/Sonido/trance-009-sound-system-dreamscape-made-with-Voicemod.wav");
        

        
        //Se crea las especificaciones del grid, osea que tendran ciertos parametros la ubicacion y la posicion de los botones
        GridBagConstraints gbc = new GridBagConstraints();
        // Espaciado entre los botones
        gbc.insets = new Insets(15, 0, 15, 0);
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        //Se crea una variable la cual contendra un tipo de fuente y el tamaño
        Font fuenteBoton = new Font("Arial", Font.BOLD, 18);
        
        //JLabel titulo con fuente y color del fondo
        JLabel titulo = new JLabel("Menu principal");
        titulo.setFont(new Font("Arial", Font.BOLD, 32));
        titulo.setForeground(Color.WHITE);
        titulo.setHorizontalAlignment(SwingConstants.CENTER);
        //JPanel para ubicarse detras del titulo y darle un contenedor visual
        JPanel panelTitulo = new JPanel();
        panelTitulo.setOpaque(true);
        panelTitulo.setBackground(new Color(0, 0, 0, 150)); 
        panelTitulo.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2)); 
        panelTitulo.setLayout(new BorderLayout());
        panelTitulo.add(titulo, BorderLayout.CENTER);
        panelTitulo.setPreferredSize(new Dimension(600, 60));
        gbc.gridy = 0;
        panelBotones.add(panelTitulo, gbc);
        
        //Se crea otro gridconstraint donde se va a definir donde iran los botones y debe centrarse en la mitad de la celda y se añade el panel de botones al contenedor principal
        GridBagConstraints gbcFrame = new GridBagConstraints();
        gbcFrame.anchor = GridBagConstraints.CENTER;
        add(panelBotones, gbcFrame);
        
        //Botones
        //Se crea los botones con sus respectivos eventos, fuente y color tanto del fondo como de la letra, ademas del numero jerarquico de ubicacion en el Grid
        
        botonVehiculos = new JButton("Menu Vehiculos");
        botonVehiculos.setFont(fuenteBoton);
        botonVehiculos.setBackground(Color.decode("#4CAF50")); 
        botonVehiculos.setForeground(Color.WHITE);
        botonVehiculos.addActionListener(e -> abrirMenuVehiculos());
        gbc.gridy = 1;
        add(botonVehiculos, gbc);

        
        botonConductores = new JButton("Menu Conductores");
        botonConductores.setFont(fuenteBoton);
        botonConductores.setBackground(Color.decode("#4CAF50")); 
        botonConductores.setForeground(Color.WHITE);
        botonConductores.addActionListener(e -> abrirMenuConductores());
        gbc.gridy = 2;
        add(botonConductores, gbc);
        
        botonProductos = new JButton("Menu Productos");
        botonProductos.setFont(fuenteBoton);
        botonProductos.setBackground(Color.decode("#4CAF50")); 
        botonProductos.setForeground(Color.WHITE);
        botonProductos.addActionListener(e -> abrirMenuProductos());
        gbc.gridy = 3;
        add(botonProductos, gbc);
        
        botonAsignacion = new JButton("Menu Para Asignar");
        botonAsignacion.setFont(fuenteBoton);
        botonAsignacion.setBackground(Color.decode("#4CAF50")); 
        botonAsignacion.setForeground(Color.WHITE);
        botonAsignacion.addActionListener(e -> abrirMenuAsignacion());
        gbc.gridy = 4;
        add(botonAsignacion, gbc);
        
        botonSalir = new JButton("Salir");
        botonSalir.setFont(fuenteBoton);
        botonSalir.setBackground(Color.decode("#F44336")); 
        botonSalir.setForeground(Color.WHITE);
        botonSalir.addActionListener(e -> Salir());
        gbc.gridy = 5;
        add(botonSalir, gbc);
        
        
        
        
        
    }
    
    private void abrirMenuAsignacion() {
        //Se crea la instancia para poder acceder y muestra el frame con el menu de asignaciones
        menuAsignacion menuAsignarFrame = new menuAsignacion();
        menuAsignarFrame.setVisible(true);
    }
    
    private void abrirMenuProductos() {
        //Se crea la instancia para poder acceder y muestra el frame con el menu de productos
        menuProductos menuProductosFrame = new menuProductos();
        menuProductosFrame.setVisible(true);
    }

    private void abrirMenuVehiculos() {
        //Se crea la instancia para poder acceder y muestra el frame con el menu de vehiculos
        menuVehiculos menuVehiculosFrame = new menuVehiculos();
        menuVehiculosFrame.setVisible(true);
    }
    private void abrirMenuConductores() {
        //Se crea la instancia para poder acceder y muestra el frame con el menu de conductores
        menuConductores tablaConductoresFrame = new menuConductores();
        tablaConductoresFrame.setVisible(true);
    }
    private void Salir() {
        //Evento para salir del sistema
        System.exit(0);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    
    public static void main(String args[]) {
        
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Principal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                SwingUtilities.invokeLater(() -> {
            Principal menu = new Principal();
            menu.setVisible(true);
        });
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
    
    //Clase donde se define la imagen del fondo del JFrame
    class fondoPanel extends JPanel{
        private Image imagen;
        @Override
        public void paint (Graphics g){
            imagen = new ImageIcon(getClass().getResource("/imagenes/vehiculo-de-entrega-de-carga.jpg")).getImage();
            g.drawImage(imagen, 0,0 , getWidth(),getHeight(), this);
            setOpaque(false);
            super.paint(g);
        }
    }
}

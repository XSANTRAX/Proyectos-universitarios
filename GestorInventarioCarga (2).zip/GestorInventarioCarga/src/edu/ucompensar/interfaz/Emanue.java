/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package edu.ucompensar.interfaz;


import Sonido.Sonido;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JPanel;

/**
 *
 * @author Usuario
 */
public class Emanue extends javax.swing.JFrame {

    fondoPanel fondo = new fondoPanel();
    
    public Emanue() {
        this.setContentPane(fondo);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(1440, 1080);
        setLocationRelativeTo(null);
        
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
class fondoPanel extends JPanel{
        private Image imagen;
        private Image cat;
        @Override
        public void paint (Graphics g){
            imagen = new ImageIcon(getClass().getResource("/imagenes/emanue.jpeg")).getImage();
            cat = new ImageIcon(getClass().getResource("/imagenes/laughing-cat.gif")).getImage();
            g.drawImage(imagen, 0,0 , getWidth(),getHeight(), this);
            g.drawImage(cat, 500, 100, this);
            setOpaque(false);
        }
    }
}

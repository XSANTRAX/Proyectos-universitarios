/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package edu.ucompensar.interfaz;

import edu.ucompensar.codigo.gestorVehiculos;
import edu.ucompensar.codigo.Conductores;
import edu.ucompensar.codigo.Conductores;
import edu.ucompensar.codigo.gestorVehiculos;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Usuario
 */
public class tablaConductores extends javax.swing.JFrame {
    gestorVehiculos gv = new gestorVehiculos();

    
     private JTable tabla;
     private JButton botonMostrar;
     private JButton botonVolver;
    /**
     * Creates new form NewJFrame
     */

    public tablaConductores() {
        
        //Titulo del frame
        
        setTitle("Lista de Conductores");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new java.awt.BorderLayout());
        setSize(1440, 1080);
        setLocationRelativeTo(null);
        
        //Se crea el boton para mostrar conductores y se le da un evento
        botonMostrar = new JButton("Mostrar Conductores");
        botonMostrar.addActionListener(e -> mostrarConductores());
        
        
        botonVolver = new JButton("Volver");
        botonVolver.addActionListener(e -> volver());
        
        

        //L
        tabla = new JTable(new DefaultTableModel(new Object[]{"Nombre", "Edad", "Cédula", "Disponibilidad"}, 0));
        JScrollPane scrollPane = new JScrollPane(tabla);

        add(scrollPane, java.awt.BorderLayout.CENTER);
        add(botonMostrar, java.awt.BorderLayout.WEST);
        add(botonVolver, java.awt.BorderLayout.SOUTH);

        setSize(400, 300);
        setVisible(true);
    }
    
    private void volver(){
        dispose();  
    }
    
    
    private void mostrarConductores() {
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
        modelo.setRowCount(0);
        
        for (Conductores conductor : gestorVehiculos.cond) {
            modelo.addRow(new Object[] {conductor.getNombre(), conductor.getEdad(), conductor.getIdentificacion(), conductor.getDisponibilidad()});
        }
       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}


package edu.ucompensar.interfaz;

import edu.ucompensar.codigo.Tractomula;
import edu.ucompensar.codigo.Vehiculo;
import edu.ucompensar.codigo.Vehiculo;
import edu.ucompensar.codigo.Volqueta;
import edu.ucompensar.codigo.Volqueta;
import edu.ucompensar.codigo.gestorVehiculos;
import edu.ucompensar.codigo.gestorVehiculos;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class tablaVehiculos extends javax.swing.JFrame {

    gestorVehiculos gestor = new gestorVehiculos();
    private JTable tabla;
    private JButton botonMostrar;
    private JButton botonVolver;
    private JButton botonCalcular;
     
    public tablaVehiculos() {
        //Titulo del frame
        setTitle("Tabla de vehiculos");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new java.awt.BorderLayout());
        setSize(1440, 1080);
        setLocationRelativeTo(null);
        
        //Se crea el boton para mostrar conductores y se le da un evento
        botonMostrar = new JButton("Mostrar vehiculos");
        botonMostrar.addActionListener(e -> mostrarVehiculos());
        
        
        botonVolver = new JButton("Volver");
        botonVolver.addActionListener(e -> volver());
        
        botonCalcular = new JButton("Calcular tarifa");
        botonCalcular.addActionListener(e -> calcularTarifa());
        
        
        //L
        tabla = new JTable(new DefaultTableModel(new Object[]{"Tipo","Marca", "Modelo", "Capacidad", "Ejes", "Placa", "Disponible"}, 0));
        JScrollPane scrollPane = new JScrollPane(tabla);

        add(scrollPane, java.awt.BorderLayout.CENTER);
        add(botonMostrar, java.awt.BorderLayout.WEST);
        add(botonVolver, java.awt.BorderLayout.SOUTH);
        add(botonCalcular, java.awt.BorderLayout.EAST);

        setSize(400, 300);
        setVisible(true);
    }
    
    private void volver(){
        dispose();  
    }
    
    
    private void calcularTarifa(){
        String placa = JOptionPane.showInputDialog(this, "Ingrese la placa del vehiculo: ");
            if (placa == null || placa.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "La placa no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
                return;  
            }
        String tonelada = JOptionPane.showInputDialog(this, "Ingrese las toneladas de la carga: ");
        int toneladas = Integer.parseInt(tonelada);
            if (tonelada == null || tonelada.trim().isEmpty()){
                JOptionPane.showMessageDialog(this, "La capacidad no puede estar vacía.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        JOptionPane.showMessageDialog(this, gestor.calculaCargaTarifa(placa, toneladas)+" pesos");
    }
    
    
    private void mostrarVehiculos() {
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
        modelo.setRowCount(0);
        
        for (Vehiculo vehiculo : gestorVehiculos.veh) {
            if(vehiculo instanceof Volqueta)
            modelo.addRow(new Object[] {"Volqueta",vehiculo.getMarca(),vehiculo.getModelo(),vehiculo.getCapacidad()+" toneladas",vehiculo.getEjes(),vehiculo.getPlaca(),vehiculo.getDisponibilidad()});
        }
        for (Vehiculo vehiculo : gestorVehiculos.veh) {
            if(vehiculo instanceof Tractomula)
            modelo.addRow(new Object[] {"Tractomula",vehiculo.getMarca(),vehiculo.getModelo(),vehiculo.getCapacidad()+" toneladas",vehiculo.getEjes(),vehiculo.getPlaca(),vehiculo.getDisponibilidad()});
        }
    }
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents




    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
